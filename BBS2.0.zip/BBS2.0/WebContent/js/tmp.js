function tmp(){
	alert("用户名或密码错误 ，请重新登录!");
}